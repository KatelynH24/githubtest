package com.serviceobjects.www;

import com.google.gson.annotations.SerializedName;

public class DPVAddressResponse {

	@SerializedName("DPVAddress")
	public DPVAddress DpvAddress;
	@SerializedName("Error")
	public Error error;
	
	
	
	
	public class DPVAddress{
		
	
		public String Address;
		public String City;
		public String State;
		public String Zip;
		public String Address2;
		public String BarcodeDigits;
		public String CarrierRoute;
		public String CongressCode;
		public String CountyCode;
		public String CountyName;
		public String FragmentHouse;
		public String FragmentPreDir;
		public String FragmentStreet;
		public String FragmentSuffix;
		public String FragmentPostDir;
		public String FragmentUnit;
		public String Fragment;
		public String FragmentPMBPrefix;
		public String FragmentPMBNumber;
		public String DPV;
		public String DPVDesc;
		public String DPVNotes;
		public String DPVNotesDesc;
		public String Corrections;
		public String CorrectionsDesc;
		public String Debug;
		
	}
	
	
	public class Error{
		
		public String Type;
		public String TypeCode;
		public String Desc;
		public String DescCode;
		
	}
}
