package com.serviceobjects.www;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.Gson;

public class AV3RestClient {

	String MainUrl, BackupUrl, ErrorMessages = null;
	int Timeout;

	public AV3RestClient() {
		MainUrl = "https://trial.serviceobjects.com/av3/api.svc/GetBestMatchesJson/";
		// Add your backup url
		BackupUrl = "https://trial.serviceobjects.com/av3/api.svc/GetBestMatchesJson/";
		Timeout = 5000;
	}

	public String getErrorMessages() {
		return this.ErrorMessages;
	}

	public BestMatchesResponse GetBestMatches(String business, String address, String address2,
			String city, String state, String postal, String licensekey)
			throws UnsupportedEncodingException {

		
		//NOTE: A missing parameter is not allowed
		if (business.isEmpty())
			business = " ";
		if (address.isEmpty())
			address = " ";
		if (address2.isEmpty())
			address2 = " ";
		if (city.isEmpty())
			city = " ";
		if (state.isEmpty())
			state = " ";
		if (postal.isEmpty())
			postal = " ";
		if (licensekey.isEmpty())
			licensekey = "yourDevKey";

		// Encoding the URL parameters
		business = URLEncoder.encode(business, "UTF-8").replaceAll("\\+", "%20");
		address = URLEncoder.encode(address, "UTF-8").replaceAll("\\+", "%20");
		address2 = URLEncoder.encode(address2, "UTF-8").replaceAll("\\+", "%20");
		city = URLEncoder.encode(city, "UTF-8").replaceAll("\\+", "%20");
		state = URLEncoder.encode(state, "UTF-8").replaceAll("\\+", "%20");
		postal = URLEncoder.encode(postal, "UTF-8").replaceAll("\\+", "%20");
		licensekey = URLEncoder.encode(licensekey, "UTF-8").replaceAll("\\+", "%20");

		 /* 
         * Due to RFC compliance, the use of URL Paths has character limitations.  
         * Certain characters are invalid and cause HTTP Errors; these characters  
         * include #, /, ?,\ as well as some high bit characters.  
         * 
         * If you suspect that this may be an issue for you then it is recommended to change your 
         * request from the URL path parameter format to the query string parameter format.  
         * Example:  
         *     FROM {data}/{data2}/{key}?format=json  
         *     TO parameter1={data1}&parameter2={data2}&licensekey={key} 
         * Another alternative is to use HTTP Post instead of HTTP Get. 
         */
		
		String MainURL = this.MainUrl + business + "/" + address + "/" + address2 + "/" + city
				+ "/" + state + "/" + postal + "/" + licensekey
				+ "?format=json";
		String BackupURL = this.BackupUrl + business + "/" + address + "/" + address2 + "/"
				+ city + "/" + state + "/" + postal + "/" + licensekey
				+ "?format=json";

		BestMatchesResponse result = GetBestMatchesResponse(MainURL);
		//NULL ERROR || FATAL ERROR RETURNED -- TRY BACKUP 
		if (ErrorMessages != null || (result.error != null && result.error.TypeCode == "3")) {
			// BACKUP
			result = GetBestMatchesResponse(BackupURL);
		}
		return result;
	}

	private BestMatchesResponse GetBestMatchesResponse(String myurl) {
		URL url = null;
		HttpsURLConnection conn = null;
		Gson gson = new Gson();
		BestMatchesResponse result = null;
		try {
			
			url = new URL(myurl);

			System.out.println(url);

			conn = (HttpsURLConnection) url.openConnection();
			conn.setConnectTimeout(Timeout);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));
			StringBuilder sb = new StringBuilder();
			String output;
			// System.out.println("info from the server \n");
			while ((output = br.readLine()) != null) {
				sb.append(output);
				//System.out.println(output);
			}

			result = gson.fromJson(sb.toString(), BestMatchesResponse.class);
			if(result == null)
				{ throw new Exception("ERROR: trying to get DPV Response");}

		} catch (Exception ex) {

			ErrorMessages = ex.getMessage();
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}

		finally {

			if (conn != null)
				conn.disconnect();
		}

		return result;

	}
}
