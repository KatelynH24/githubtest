package com.serviceobjects.www;

import com.google.gson.annotations.SerializedName;

public class BestMatchesResponse {

	@SerializedName("Addresses")
	public Address[] Addresses;
	@SerializedName("Error")
	public Error error;
	@SerializedName("IsCASS")
	public boolean IsCASS;
	
	
	
	
	public class Address{
		public String Address1;
		public String Address2;
		public String City;
		public String State;
		public String Zip;
		public String IsResidential;
		public String DPV;
		public String DPVDesc;
		public String DPVNotes;
		public String DPVNotesDesc;
		public String Corrections;
		public String CorrectionsDesc;
		public String BarcodeDigits;
		public String CarrierRoute;
		public String CongressCode;
		public String CountyCode;
		public String CountyName;
		public String FragmentHouse;
		public String FragmentPreDir;
		public String FragmentStreet;
		public String FragmentSuffix;
		public String FragmentPostDir;
		public String FragmentUnit;
		public String Fragment;
		public String FragmentPMBPrefix;
		public String FragmentPMBNumber;
	}
	
	
	public class Error{
		
		public String Type;
		public String TypeCode;
		public String Desc;
		public String DescCode;
		
	}
}
