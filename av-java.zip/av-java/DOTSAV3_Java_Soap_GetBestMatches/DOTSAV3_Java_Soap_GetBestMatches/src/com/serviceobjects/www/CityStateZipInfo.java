/**
 * CityStateZipInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.serviceobjects.www;

public class CityStateZipInfo  implements java.io.Serializable {
    private java.lang.String city;

    private java.lang.String state;

    private java.lang.String zip;

    private java.lang.String generalDeliveryService;

    private java.lang.String POBoxService;

    private java.lang.String streetService;

    private java.lang.String RRHCService;

    private java.lang.String urbanizationService;

    private java.lang.String POBoxRangeLow;

    private java.lang.String POBoxRangeHigh;

    private java.lang.String isUniqueZipCode;

    private java.lang.String debug;

    public CityStateZipInfo() {
    }

    public CityStateZipInfo(
           java.lang.String city,
           java.lang.String state,
           java.lang.String zip,
           java.lang.String generalDeliveryService,
           java.lang.String POBoxService,
           java.lang.String streetService,
           java.lang.String RRHCService,
           java.lang.String urbanizationService,
           java.lang.String POBoxRangeLow,
           java.lang.String POBoxRangeHigh,
           java.lang.String isUniqueZipCode,
           java.lang.String debug) {
           this.city = city;
           this.state = state;
           this.zip = zip;
           this.generalDeliveryService = generalDeliveryService;
           this.POBoxService = POBoxService;
           this.streetService = streetService;
           this.RRHCService = RRHCService;
           this.urbanizationService = urbanizationService;
           this.POBoxRangeLow = POBoxRangeLow;
           this.POBoxRangeHigh = POBoxRangeHigh;
           this.isUniqueZipCode = isUniqueZipCode;
           this.debug = debug;
    }


    /**
     * Gets the city value for this CityStateZipInfo.
     * 
     * @return city
     */
    public java.lang.String getCity() {
        return city;
    }


    /**
     * Sets the city value for this CityStateZipInfo.
     * 
     * @param city
     */
    public void setCity(java.lang.String city) {
        this.city = city;
    }


    /**
     * Gets the state value for this CityStateZipInfo.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this CityStateZipInfo.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the zip value for this CityStateZipInfo.
     * 
     * @return zip
     */
    public java.lang.String getZip() {
        return zip;
    }


    /**
     * Sets the zip value for this CityStateZipInfo.
     * 
     * @param zip
     */
    public void setZip(java.lang.String zip) {
        this.zip = zip;
    }


    /**
     * Gets the generalDeliveryService value for this CityStateZipInfo.
     * 
     * @return generalDeliveryService
     */
    public java.lang.String getGeneralDeliveryService() {
        return generalDeliveryService;
    }


    /**
     * Sets the generalDeliveryService value for this CityStateZipInfo.
     * 
     * @param generalDeliveryService
     */
    public void setGeneralDeliveryService(java.lang.String generalDeliveryService) {
        this.generalDeliveryService = generalDeliveryService;
    }


    /**
     * Gets the POBoxService value for this CityStateZipInfo.
     * 
     * @return POBoxService
     */
    public java.lang.String getPOBoxService() {
        return POBoxService;
    }


    /**
     * Sets the POBoxService value for this CityStateZipInfo.
     * 
     * @param POBoxService
     */
    public void setPOBoxService(java.lang.String POBoxService) {
        this.POBoxService = POBoxService;
    }


    /**
     * Gets the streetService value for this CityStateZipInfo.
     * 
     * @return streetService
     */
    public java.lang.String getStreetService() {
        return streetService;
    }


    /**
     * Sets the streetService value for this CityStateZipInfo.
     * 
     * @param streetService
     */
    public void setStreetService(java.lang.String streetService) {
        this.streetService = streetService;
    }


    /**
     * Gets the RRHCService value for this CityStateZipInfo.
     * 
     * @return RRHCService
     */
    public java.lang.String getRRHCService() {
        return RRHCService;
    }


    /**
     * Sets the RRHCService value for this CityStateZipInfo.
     * 
     * @param RRHCService
     */
    public void setRRHCService(java.lang.String RRHCService) {
        this.RRHCService = RRHCService;
    }


    /**
     * Gets the urbanizationService value for this CityStateZipInfo.
     * 
     * @return urbanizationService
     */
    public java.lang.String getUrbanizationService() {
        return urbanizationService;
    }


    /**
     * Sets the urbanizationService value for this CityStateZipInfo.
     * 
     * @param urbanizationService
     */
    public void setUrbanizationService(java.lang.String urbanizationService) {
        this.urbanizationService = urbanizationService;
    }


    /**
     * Gets the POBoxRangeLow value for this CityStateZipInfo.
     * 
     * @return POBoxRangeLow
     */
    public java.lang.String getPOBoxRangeLow() {
        return POBoxRangeLow;
    }


    /**
     * Sets the POBoxRangeLow value for this CityStateZipInfo.
     * 
     * @param POBoxRangeLow
     */
    public void setPOBoxRangeLow(java.lang.String POBoxRangeLow) {
        this.POBoxRangeLow = POBoxRangeLow;
    }


    /**
     * Gets the POBoxRangeHigh value for this CityStateZipInfo.
     * 
     * @return POBoxRangeHigh
     */
    public java.lang.String getPOBoxRangeHigh() {
        return POBoxRangeHigh;
    }


    /**
     * Sets the POBoxRangeHigh value for this CityStateZipInfo.
     * 
     * @param POBoxRangeHigh
     */
    public void setPOBoxRangeHigh(java.lang.String POBoxRangeHigh) {
        this.POBoxRangeHigh = POBoxRangeHigh;
    }


    /**
     * Gets the isUniqueZipCode value for this CityStateZipInfo.
     * 
     * @return isUniqueZipCode
     */
    public java.lang.String getIsUniqueZipCode() {
        return isUniqueZipCode;
    }


    /**
     * Sets the isUniqueZipCode value for this CityStateZipInfo.
     * 
     * @param isUniqueZipCode
     */
    public void setIsUniqueZipCode(java.lang.String isUniqueZipCode) {
        this.isUniqueZipCode = isUniqueZipCode;
    }


    /**
     * Gets the debug value for this CityStateZipInfo.
     * 
     * @return debug
     */
    public java.lang.String getDebug() {
        return debug;
    }


    /**
     * Sets the debug value for this CityStateZipInfo.
     * 
     * @param debug
     */
    public void setDebug(java.lang.String debug) {
        this.debug = debug;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CityStateZipInfo)) return false;
        CityStateZipInfo other = (CityStateZipInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.city==null && other.getCity()==null) || 
             (this.city!=null &&
              this.city.equals(other.getCity()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.zip==null && other.getZip()==null) || 
             (this.zip!=null &&
              this.zip.equals(other.getZip()))) &&
            ((this.generalDeliveryService==null && other.getGeneralDeliveryService()==null) || 
             (this.generalDeliveryService!=null &&
              this.generalDeliveryService.equals(other.getGeneralDeliveryService()))) &&
            ((this.POBoxService==null && other.getPOBoxService()==null) || 
             (this.POBoxService!=null &&
              this.POBoxService.equals(other.getPOBoxService()))) &&
            ((this.streetService==null && other.getStreetService()==null) || 
             (this.streetService!=null &&
              this.streetService.equals(other.getStreetService()))) &&
            ((this.RRHCService==null && other.getRRHCService()==null) || 
             (this.RRHCService!=null &&
              this.RRHCService.equals(other.getRRHCService()))) &&
            ((this.urbanizationService==null && other.getUrbanizationService()==null) || 
             (this.urbanizationService!=null &&
              this.urbanizationService.equals(other.getUrbanizationService()))) &&
            ((this.POBoxRangeLow==null && other.getPOBoxRangeLow()==null) || 
             (this.POBoxRangeLow!=null &&
              this.POBoxRangeLow.equals(other.getPOBoxRangeLow()))) &&
            ((this.POBoxRangeHigh==null && other.getPOBoxRangeHigh()==null) || 
             (this.POBoxRangeHigh!=null &&
              this.POBoxRangeHigh.equals(other.getPOBoxRangeHigh()))) &&
            ((this.isUniqueZipCode==null && other.getIsUniqueZipCode()==null) || 
             (this.isUniqueZipCode!=null &&
              this.isUniqueZipCode.equals(other.getIsUniqueZipCode()))) &&
            ((this.debug==null && other.getDebug()==null) || 
             (this.debug!=null &&
              this.debug.equals(other.getDebug())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCity() != null) {
            _hashCode += getCity().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getZip() != null) {
            _hashCode += getZip().hashCode();
        }
        if (getGeneralDeliveryService() != null) {
            _hashCode += getGeneralDeliveryService().hashCode();
        }
        if (getPOBoxService() != null) {
            _hashCode += getPOBoxService().hashCode();
        }
        if (getStreetService() != null) {
            _hashCode += getStreetService().hashCode();
        }
        if (getRRHCService() != null) {
            _hashCode += getRRHCService().hashCode();
        }
        if (getUrbanizationService() != null) {
            _hashCode += getUrbanizationService().hashCode();
        }
        if (getPOBoxRangeLow() != null) {
            _hashCode += getPOBoxRangeLow().hashCode();
        }
        if (getPOBoxRangeHigh() != null) {
            _hashCode += getPOBoxRangeHigh().hashCode();
        }
        if (getIsUniqueZipCode() != null) {
            _hashCode += getIsUniqueZipCode().hashCode();
        }
        if (getDebug() != null) {
            _hashCode += getDebug().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CityStateZipInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.serviceobjects.com", "CityStateZipInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "City"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "Zip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("generalDeliveryService");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "GeneralDeliveryService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POBoxService");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "POBoxService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("streetService");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "StreetService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RRHCService");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "RRHCService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urbanizationService");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "UrbanizationService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POBoxRangeLow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "POBoxRangeLow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POBoxRangeHigh");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "POBoxRangeHigh"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isUniqueZipCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "IsUniqueZipCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("debug");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "Debug"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
