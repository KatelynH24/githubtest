/**
 * ParsedAddressResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.serviceobjects.www;

public class ParsedAddressResponse  implements java.io.Serializable {
    private com.serviceobjects.www.AddressFragments addressFragments;

    private com.serviceobjects.www.AV3Error error;

    public ParsedAddressResponse() {
    }

    public ParsedAddressResponse(
           com.serviceobjects.www.AddressFragments addressFragments,
           com.serviceobjects.www.AV3Error error) {
           this.addressFragments = addressFragments;
           this.error = error;
    }


    /**
     * Gets the addressFragments value for this ParsedAddressResponse.
     * 
     * @return addressFragments
     */
    public com.serviceobjects.www.AddressFragments getAddressFragments() {
        return addressFragments;
    }


    /**
     * Sets the addressFragments value for this ParsedAddressResponse.
     * 
     * @param addressFragments
     */
    public void setAddressFragments(com.serviceobjects.www.AddressFragments addressFragments) {
        this.addressFragments = addressFragments;
    }


    /**
     * Gets the error value for this ParsedAddressResponse.
     * 
     * @return error
     */
    public com.serviceobjects.www.AV3Error getError() {
        return error;
    }


    /**
     * Sets the error value for this ParsedAddressResponse.
     * 
     * @param error
     */
    public void setError(com.serviceobjects.www.AV3Error error) {
        this.error = error;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ParsedAddressResponse)) return false;
        ParsedAddressResponse other = (ParsedAddressResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.addressFragments==null && other.getAddressFragments()==null) || 
             (this.addressFragments!=null &&
              this.addressFragments.equals(other.getAddressFragments()))) &&
            ((this.error==null && other.getError()==null) || 
             (this.error!=null &&
              this.error.equals(other.getError())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddressFragments() != null) {
            _hashCode += getAddressFragments().hashCode();
        }
        if (getError() != null) {
            _hashCode += getError().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ParsedAddressResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.serviceobjects.com", "ParsedAddressResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addressFragments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "AddressFragments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.serviceobjects.com", "AddressFragments"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("error");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.serviceobjects.com", "Error"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.serviceobjects.com", "AV3Error"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
