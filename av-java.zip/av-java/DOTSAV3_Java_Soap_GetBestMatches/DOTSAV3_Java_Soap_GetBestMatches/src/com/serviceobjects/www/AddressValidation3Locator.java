/**
 * AddressValidation3Locator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.serviceobjects.www;

public class AddressValidation3Locator extends org.apache.axis.client.Service implements com.serviceobjects.www.AddressValidation3 {

    public AddressValidation3Locator() {
    }


    public AddressValidation3Locator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AddressValidation3Locator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for DOTSAddressValidation3
    private java.lang.String DOTSAddressValidation3_address = "http://trial.serviceobjects.com/AV3/api.svc/soap";

    public java.lang.String getDOTSAddressValidation3Address() {
        return DOTSAddressValidation3_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String DOTSAddressValidation3WSDDServiceName = "DOTSAddressValidation3";

    public java.lang.String getDOTSAddressValidation3WSDDServiceName() {
        return DOTSAddressValidation3WSDDServiceName;
    }

    public void setDOTSAddressValidation3WSDDServiceName(java.lang.String name) {
        DOTSAddressValidation3WSDDServiceName = name;
    }

    public com.serviceobjects.www.IAddressValidation3 getDOTSAddressValidation3() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(DOTSAddressValidation3_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getDOTSAddressValidation3(endpoint);
    }

    public com.serviceobjects.www.IAddressValidation3 getDOTSAddressValidation3(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.serviceobjects.www.DOTSAddressValidation3Stub _stub = new com.serviceobjects.www.DOTSAddressValidation3Stub(portAddress, this);
            _stub.setPortName(getDOTSAddressValidation3WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setDOTSAddressValidation3EndpointAddress(java.lang.String address) {
        DOTSAddressValidation3_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.serviceobjects.www.IAddressValidation3.class.isAssignableFrom(serviceEndpointInterface)) {
                com.serviceobjects.www.DOTSAddressValidation3Stub _stub = new com.serviceobjects.www.DOTSAddressValidation3Stub(new java.net.URL(DOTSAddressValidation3_address), this);
                _stub.setPortName(getDOTSAddressValidation3WSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("DOTSAddressValidation3".equals(inputPortName)) {
            return getDOTSAddressValidation3();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.serviceobjects.com", "AddressValidation3");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.serviceobjects.com", "DOTSAddressValidation3"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("DOTSAddressValidation3".equals(portName)) {
            setDOTSAddressValidation3EndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
