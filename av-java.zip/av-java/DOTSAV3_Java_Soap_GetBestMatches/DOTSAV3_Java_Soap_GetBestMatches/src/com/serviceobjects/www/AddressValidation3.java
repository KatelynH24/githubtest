/**
 * AddressValidation3.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.serviceobjects.www;

public interface AddressValidation3 extends javax.xml.rpc.Service {
    public java.lang.String getDOTSAddressValidation3Address();

    public com.serviceobjects.www.IAddressValidation3 getDOTSAddressValidation3() throws javax.xml.rpc.ServiceException;

    public com.serviceobjects.www.IAddressValidation3 getDOTSAddressValidation3(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
